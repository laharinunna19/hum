# Three of Us — Lahari • Renu • Varshini

A private friendship-story website built from the uploaded photos.

## Story order
1. Renu solo
2. Varshini / Bittu solo
3. Renu × Varshini — four-year friendship
4. Wait…
5. Lahari enters
6. Lahari × Renu
7. Lahari × Varshini
8. All three — Kangaru Melam + Clumsy Ones
9. White + red meaning
10. Final screen: Lahari • Renu • Varshini

## Open locally
Open `index.html` in a browser.

## Music
The website displays the selected song references, but no copyrighted audio files are bundled. If you own/provide audio files, add them to an `audio/` folder and wire them into `script.js`.

## Share online
Upload all files to a GitHub repository and enable GitHub Pages. Then share the generated Pages link.
